# CareerHub – Job Board Landing Page

A responsive static job board inspired by Jobster, built with **HTML, CSS, and a bit of JavaScript**.

## Live features

- Clean, modern hero with search bar
- Category grid & featured job cards
- **Dark mode** toggle (persisted in localStorage)
- **Save / unsave** jobs (heart icon, persisted)
- **Client-side search & location filter**
- Popular search chips & category filtering
- Toast notifications
- Fully responsive (desktop → mobile)

## Project structure

```
CareerHub/
├── index.html
├── styles.css
├── script.js
└── README.md
```

## How to run

Open `index.html` in any modern browser. No build step or server required.

## Modifications from the original

| Area        | Change                                      |
|-------------|---------------------------------------------|
| Branding    | Jobster → **CareerHub**                     |
| Accent color| Slightly warmer coral / blue palette        |
| Content     | Updated job titles, companies, stats        |
| Image       | Different Unsplash portrait                 |
| JavaScript  | Dark mode, save jobs, search/filter, toasts |
| CSS         | CSS variables + dark theme support          |

## Technologies

- HTML5 (semantic)
- CSS3 (Grid, Flexbox, custom properties, media queries)
- Vanilla JavaScript (ES6+)

Created for learning and practice.
