/**
 * CareerHub – lightweight interactivity
 * - Dark mode toggle (persisted)
 * - Save / unsave job cards
 * - Client-side search & filter
 * - Popular search chips
 * - Toast notifications
 */

(function () {
  'use strict';

  // ---------- DOM refs ----------
  const themeToggle = document.getElementById('themeToggle');
  const searchForm = document.getElementById('searchForm');
  const searchInput = document.getElementById('searchInput');
  const locationSelect = document.getElementById('locationSelect');
  const jobGrid = document.getElementById('jobGrid');
  const jobCards = Array.from(document.querySelectorAll('.job-card'));
  const filterStatus = document.getElementById('filterStatus');
  const noResults = document.getElementById('noResults');
  const toast = document.getElementById('toast');
  const popularLinks = document.querySelectorAll('.popular-searches a[data-search]');
  const categoryCards = document.querySelectorAll('.category-card[data-category]');

  // ---------- Dark mode ----------
  function applyTheme(isDark) {
    document.body.classList.toggle('dark', isDark);
    themeToggle.textContent = isDark ? '☀' : '☾';
    themeToggle.setAttribute('aria-label', isDark ? 'Switch to light mode' : 'Switch to dark mode');
    localStorage.setItem('careerhub-theme', isDark ? 'dark' : 'light');
  }

  const savedTheme = localStorage.getItem('careerhub-theme');
  if (savedTheme === 'dark') applyTheme(true);

  themeToggle.addEventListener('click', () => {
    applyTheme(!document.body.classList.contains('dark'));
  });

  // ---------- Toast ----------
  let toastTimer;
  function showToast(message) {
    toast.textContent = message;
    toast.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.remove('show'), 2200);
  }

  // ---------- Save jobs ----------
  function loadSavedJobs() {
    try {
      return JSON.parse(localStorage.getItem('careerhub-saved') || '[]');
    } catch {
      return [];
    }
  }

  function persistSavedJobs(list) {
    localStorage.setItem('careerhub-saved', JSON.stringify(list));
  }

  const savedJobs = new Set(loadSavedJobs());

  jobCards.forEach((card) => {
    const btn = card.querySelector('.save-btn');
    const title = card.dataset.title;
    if (savedJobs.has(title)) {
      btn.classList.add('saved');
      btn.textContent = '♥';
      btn.dataset.saved = 'true';
    }

    btn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      const isSaved = btn.dataset.saved === 'true';
      if (isSaved) {
        btn.classList.remove('saved');
        btn.textContent = '♡';
        btn.dataset.saved = 'false';
        savedJobs.delete(title);
        showToast(`Removed “${title}” from saved`);
      } else {
        btn.classList.add('saved');
        btn.textContent = '♥';
        btn.dataset.saved = 'true';
        savedJobs.add(title);
        showToast(`Saved “${title}”`);
      }
      persistSavedJobs([...savedJobs]);
    });
  });

  // ---------- Search & filter ----------
  function filterJobs() {
    const query = (searchInput.value || '').trim().toLowerCase();
    const location = (locationSelect.value || '').trim().toLowerCase();
    let visible = 0;

    jobCards.forEach((card) => {
      const title = (card.dataset.title || '').toLowerCase();
      const category = (card.dataset.category || '').toLowerCase();
      const loc = (card.dataset.location || '').toLowerCase();
      const text = `${title} ${category} ${loc}`;

      const matchesQuery = !query || text.includes(query);
      const matchesLocation = !location || loc.includes(location);

      if (matchesQuery && matchesLocation) {
        card.classList.remove('hidden');
        visible++;
      } else {
        card.classList.add('hidden');
      }
    });

    if (query || location) {
      filterStatus.hidden = false;
      filterStatus.textContent = `Showing ${visible} job${visible === 1 ? '' : 's'}${query ? ` for “${searchInput.value.trim()}”` : ''}${location ? ` in ${locationSelect.value}` : ''}`;
    } else {
      filterStatus.hidden = true;
    }

    noResults.hidden = visible > 0;
  }

  searchForm.addEventListener('submit', (e) => {
    e.preventDefault();
    filterJobs();
    document.getElementById('jobs').scrollIntoView({ behavior: 'smooth' });
  });

  searchInput.addEventListener('input', () => {
    // live filter while typing
    filterJobs();
  });

  locationSelect.addEventListener('change', filterJobs);

  // Popular search chips
  popularLinks.forEach((link) => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      searchInput.value = link.dataset.search || '';
      filterJobs();
      document.getElementById('jobs').scrollIntoView({ behavior: 'smooth' });
    });
  });

  // Category cards act as filters
  categoryCards.forEach((card) => {
    card.addEventListener('click', (e) => {
      e.preventDefault();
      const cat = card.dataset.category || '';
      searchInput.value = cat;
      locationSelect.value = '';
      filterJobs();
      document.getElementById('jobs').scrollIntoView({ behavior: 'smooth' });
    });
  });

  // Keyboard: Escape clears search
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && (searchInput.value || locationSelect.value)) {
      searchInput.value = '';
      locationSelect.value = '';
      filterJobs();
      showToast('Filters cleared');
    }
  });
})();
